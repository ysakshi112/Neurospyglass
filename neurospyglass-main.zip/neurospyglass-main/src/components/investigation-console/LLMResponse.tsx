export default function LLMResponse() {
    return (
      <div className="p-2 bg-white shadow rounded">
        <p>LLM Response will be shown here...</p>
      </div>
    );
  }
  