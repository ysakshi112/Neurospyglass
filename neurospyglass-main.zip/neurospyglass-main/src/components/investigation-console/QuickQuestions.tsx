export default function QuickQuestions() {
    return (
      <div className="p-2 bg-white shadow rounded space-x-2">
        <button className="bg-blue-500 text-white px-4 py-2 rounded">What happened?</button>
        <button className="bg-blue-500 text-white px-4 py-2 rounded">Key events?</button>
      </div>
    );
  }
  