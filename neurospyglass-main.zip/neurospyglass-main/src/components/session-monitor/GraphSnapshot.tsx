export default function GraphSnapshot() {
    return <div className="p-2 bg-white shadow rounded">Live Temporal Graph Snapshot</div>;
  }
  