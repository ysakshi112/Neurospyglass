export default function EventHoverDetails() {
    return <div className="p-2 bg-white shadow rounded">Hover to View Event Details</div>;
  }
  