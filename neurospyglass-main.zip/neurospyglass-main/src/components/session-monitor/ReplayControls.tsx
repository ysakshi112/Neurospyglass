export default function ReplayControls() {
    return <div className="p-2 bg-white shadow rounded">Pause & Replay Controls</div>;
  }
  