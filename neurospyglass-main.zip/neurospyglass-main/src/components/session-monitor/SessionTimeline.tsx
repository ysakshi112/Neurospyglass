export default function SessionTimeline() {
    return <div className="p-2 bg-white shadow rounded">Real-time Session Timeline</div>;
  }
  