export default function EventFilters() {
    return <div className="p-2 bg-white shadow rounded">Event Filters - Type, Time, User</div>;
  }
  